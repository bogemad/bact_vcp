#!/usr/bin/env python
'''
Tests for bamutils minorallele
'''

import unittest


class MinorAlleleTest(unittest.TestCase):
    def testMinor1(self):
        'MISSING TEST/EXPERIMENTAL'
        pass

if __name__ == '__main__':
    unittest.main()
