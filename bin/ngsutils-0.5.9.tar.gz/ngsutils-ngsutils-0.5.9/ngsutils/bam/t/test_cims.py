#!/usr/bin/env python
'''
Tests for bamutils cims
'''

import unittest


class CIMSTest(unittest.TestCase):
    def testCIMS1(self):
        'MISSING TEST/EXPERIMENTAL'
        pass

if __name__ == '__main__':
    unittest.main()
